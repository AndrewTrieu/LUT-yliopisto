from datetime import datetime
now = datetime.now()

# Return to menu


def back():
    input('\nPress ENTER to return to main menu...')
    menu()

# Modify vehicle database: A <-> R


def modify(tf, mod):
    if tf:
        with open(r'Vehicle.txt', 'w+') as rew:
            for w in range(len(mod)):
                rew.write(str(mod[w]))

# Display available cars


def displayCars():
    with open(r'Vehicle.txt', 'r') as f1:
        cars1 = f1.readlines()
        for i in range(len(cars1)):
            car1 = cars1[i].split(',')
            car1 = [x.replace('\n', "") for x in car1]
            if car1[5] == 'A':
                available = ','.join(car1)
                print(available)

# Write down rented vehicles and completed rents


def rentDetails(path, app):
    plate = app.split(',')
    if path == 1:
        with open(r'rentVehicle.txt', 'a') as q:
            q.write(str(app))
            print('\nCar '+plate[0]+' is rented successfully.')
    elif path == 2:
        with open(r'Transactions.txt', 'a') as p:
            p.write(str(app))
            print('\nCar '+plate[0]+' is returned successfully.')

# Rent a car


def rentVehicle(id1):
    with open(r'Vehicle.txt', 'r') as f2:
        cars2 = f2.readlines()
        for j in range(len(cars2)):
            car2 = cars2[j].split(',')
            car2 = [y.replace('\n', '') for y in car2]
            if id1 == car2[0]:
                if car2[5] == 'A':
                    rentID = input('Enter Renter ID: ')
                    odo = input('Enter odometer reading at time of renting: ')
                    print('\nCar '+car2[0]+' is rented to '+rentID)
                    print(
                        '        ******************* Vehicle Details *********************')
                    print('Vehicle ID: '+id1 + '    Description: ' +
                          car2[1]+'    Daily rate: '+car2[4]+'    Status: R\n'+'Renter ID: '+rentID+'    Date/time of rent: ' + now.strftime("%d/%m/%Y %H:%M")+'    Rent starting odometer: '+odo)
                    car2[5] = 'R\n'
                    appnew = (id1+','+rentID+',' +
                              now.strftime("%d/%m/%Y %H:%M")+','+odo+'\n')
                    rentDetails(1, appnew)
                    cars2[j] = ','.join(car2)
                    return True, cars2
                elif car2[5] == 'R':
                    print('Vehicle is on rent.')
                    return False, []
        else:
            print('Vehicle does not exist.')
            return False, []

# Return a rented car


def rentComplete(id2):
    with open(r'Vehicle.txt', 'r') as f3:
        cars3 = f3.readlines()
        for r in range(len(cars3)):
            car3 = cars3[r].split(',')
            car3 = [z.replace('\n', '') for z in car3]
            if id2 == car3[0]:
                if car3[5] == 'R':
                    with open(r'rentVehicle.txt', 'r') as f4:
                        rented = f4.readlines()
                        for v in range(len(rented)):
                            car4 = rented[v].split(',')
                            car4 = [u.replace('\n', '') for u in car4]
                            if car4[0] == id2:
                                odo2 = input(
                                    'Enter odometer reading at time of returning: ')
                                startdate = car4[2]
                                dayrent = datetime.strptime(
                                    startdate, '%d/%m/%Y %H:%M')
                                daydelta = (now - dayrent).days
                                charge = str(
                                    ((daydelta+1)*float(car3[4])))
                                print('\nCar '+id2 +
                                      ' is returned from '+car4[1])
                                print(
                                    '        ******************* Vehicle Details *********************')
                                print('Vehicle ID: '+id2 + '    Description: ' +
                                      car3[1]+'    Daily rate: '+car3[4]+'\nRenter ID: '+car4[1]+'    Date/time of return: ' + now.strftime("%d/%m/%Y %H:%M") + '\nRent starting odometer: '+car4[3]+'    Rent end odometer: '+odo2+'    Rental charges: '+charge)
                                car3[5] = 'A\n'
                                appdone = (id2+',' + car4[1]+',' + now.strftime(
                                    "%d/%m/%Y %H:%M") + ','+car4[3]+','+odo2+','+charge+'\n')
                                rentDetails(2, appdone)
                                cars3[r] = ','.join(car3)
                                return True, cars3
                        else:
                            print(
                                "rentVehicle.txt's content error: Vehicle is on rent but no rent details found.")
                            return False, []
                elif car3[5] == 'A':
                    print('Vehicle is not on rent.')
                    return False, []
        else:
            print('Vehicle does not exist.')
            return False, []

# Main Menu


def menu():
    print('\n         Vehicle Menu')
    print('Display Available Cars       1')
    print('Rent Vehicle                 2')
    print('Complete Rent                3')
    print('Exit                         4')
    try:
        choice = int(input('\nChoose your options: '))
    except ValueError:
        print("\nInvalid choice.")
        back()
    except TypeError:
        print("\nInvalid choice.")
        back()
    else:
        if choice == 1:
            displayCars()
            back()
        elif choice == 2:
            idc2 = input('\nEnter Vehicle ID: ')
            o2 = rentVehicle(idc2)
            modify(o2[0], o2[1])
            back()
        elif choice == 3:
            idc3 = input('\nEnter Vehicle ID: ')
            o3 = rentComplete(idc3)
            modify(o3[0], o3[1])
            back()
        elif choice == 4:
            print('\nThanks for using Car Rental System. Bye! Bye!')
            return
        else:
            print('\nInvalid choice.')
            back()


menu()
