package Main;

public class Write {

}
