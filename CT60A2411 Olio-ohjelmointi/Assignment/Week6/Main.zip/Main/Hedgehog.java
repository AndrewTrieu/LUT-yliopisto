package Main;

public class Hedgehog extends Animal {

    public Hedgehog(String name) {
        super(name, "Hedgehog");
    }

    public String getName() {
        return this.name;
    }
}
