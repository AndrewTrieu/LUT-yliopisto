package Main;

public class Lion extends Animal {

    public Lion(String name, String spec, int age) {
        super(name, spec, age);
        
    }
    
}
