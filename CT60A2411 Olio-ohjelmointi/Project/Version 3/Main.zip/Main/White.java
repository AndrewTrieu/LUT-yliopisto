package Main;

public class White extends Lutemon {
    protected String name, color;
    protected int attack, defense, exp, health, maxHealth, id;

    public White(String name, String color, int exp, int attack, int defense, int health) {
        super(name, color, exp, attack, defense, health);
    }

}
