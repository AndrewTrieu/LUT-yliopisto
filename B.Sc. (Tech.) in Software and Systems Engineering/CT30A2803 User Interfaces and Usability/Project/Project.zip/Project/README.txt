Every file is included in the project even the dependencies.project is semi responsive and the icons and textboxes are all custom created.
After making sure you are in the directory folder then run the following commands in same order:


flutter pub get


flutter run --no-sound-null-safety