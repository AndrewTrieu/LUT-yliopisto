#ifndef PROD_H   /* Include guard */
#define PROD_H

int prod(int x, int y);  /* sum-function declaration */

#endif // PROD_H
