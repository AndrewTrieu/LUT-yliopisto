#ifndef SUM_H   /* Include guard */
#define SUM_H

int sum(int x, int y);  /* sum-function declaration */

#endif // SUM_H
