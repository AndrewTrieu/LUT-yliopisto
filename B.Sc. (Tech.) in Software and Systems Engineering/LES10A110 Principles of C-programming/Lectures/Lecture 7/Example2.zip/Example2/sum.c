int sum(int x, int y)    /* Function definition */
{
    return x + y;
}