int prod(int x, int y)    /* Function definition */
{
    return x * y;
}