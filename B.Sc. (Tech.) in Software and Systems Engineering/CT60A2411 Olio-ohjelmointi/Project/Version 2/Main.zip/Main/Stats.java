package Main;

public interface Stats {
    String printStats();
}
