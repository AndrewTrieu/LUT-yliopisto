/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.gpiste.starbase;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author gessle
 */
public class Main {
    
    
    public static void main(String[] args) {
       
       Starship sh = new Starship();
       
       sh.addAstronaut(new Astronaut("Lee", 42));
       sh.addAstronaut(new Astronaut("Anna", 37));
       sh.addAstronaut(new Astronaut("Ernest", 48));
       sh.addAstronaut(new Astronaut("Daniela", 26));
       sh.addCargo("Satellite A");
       sh.addCargo("Satellite B");
       
       sh.printInformation();
        
        
       LongMarch9 lm = new LongMarch9();
       
       lm.addAstronaut(new Astronaut("Lee", 23));
       lm.addAstronaut(new Astronaut("Chen", 41));
       lm.addAstronaut(new Astronaut("Ah Lam", 55));
       lm.addAstronaut(new Astronaut("Zhiqiang", 67));
       lm.addAstronaut(new Astronaut("Lok", 41));
       lm.addCargo("Moon rover");
       
       lm.printInformation();
       
       
       sh.launch(true);
       sh.land();
       //lm.land(); Not available
       
       
       SaturnV sv = new SaturnV();
       
       sv.addAstronaut(new Astronaut("Ernest", 48));
       sv.addAstronaut(new Astronaut("Daniela", 26));
       
       sv.doTvInteview();
        
        
    }
}
