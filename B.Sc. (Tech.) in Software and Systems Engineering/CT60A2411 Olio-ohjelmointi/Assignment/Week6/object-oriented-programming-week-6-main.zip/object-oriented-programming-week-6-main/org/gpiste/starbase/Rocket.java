/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.gpiste.starbase;

import java.util.ArrayList;

/**
 *
 * @author gessle
 */
public class Rocket {
    final String name;
    protected ArrayList<String> cargo = new ArrayList<>();
    protected ArrayList<Astronaut> astronauts = new ArrayList<>();
    final int maxSizeOfCargo;
    final int maxNumberOfAstronauts;
    
    public Rocket(String name, int maxSizeOfCargo, int maxNumberOfAstronauts) {
        this.name = name;
        this.maxSizeOfCargo = 100;
        this.maxNumberOfAstronauts = maxNumberOfAstronauts;
    }
    
    public void printInformation() {
        System.out.println(name + " has the following astronauts:");
        for(Astronaut s: astronauts) {
            System.out.println("* " + s.getName());
        }
        
        System.out.println("And the following cargo:");
        for(String s: cargo) {
            System.out.println("* " + s);
        }
    }
    
    
    public void addAstronaut(Astronaut astronaut) {
        if (astronauts.size() < this.maxNumberOfAstronauts) {
            astronauts.add(astronaut);
        }
    }
    
    public Astronaut getAstronaut() {
        if (astronauts.size() > 0) {
            return astronauts.remove(0);
        }
        else {
            return null;
        }
    }
    
    public int getNumberOfAstronauts() {
        return astronauts.size();
    }
    
    
    public void addCargo(String cargo) {
        if (this.cargo.size() < this.maxSizeOfCargo) {
            this.cargo.add(cargo);
        }
    }
    
    public void addCargo(ArrayList<String> lostsOfCargo) {
        if (this.cargo.size() + lostsOfCargo.size() < this.maxSizeOfCargo) {
            this.cargo.addAll(lostsOfCargo);
        }
    }
    
    public String getCargo() {
        if (cargo.size() > 0) {
            return cargo.remove(0);
        }
        else {
            return "Error";
        }
    }
    
    public int getAmountOfCargo() {
        return cargo.size();
    }
    
    
    public void launch() {
    
        System.out.println(name + " has been *test* launched succesfully!");
    }
    
    public void launch(boolean realDeal) {
        if (realDeal) {
            if (!cargo.isEmpty() || !astronauts.isEmpty()) {
                System.out.println(name + " has been launched succesfully!");
            }
            else {
                System.out.println("Cannot launch empty rocket!");
            }
        }
        else {
            this.launch();
        }
    }
    
}
