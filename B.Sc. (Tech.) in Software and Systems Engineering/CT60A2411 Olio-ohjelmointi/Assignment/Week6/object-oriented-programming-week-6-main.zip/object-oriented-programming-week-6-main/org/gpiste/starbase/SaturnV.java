/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.gpiste.starbase;

/**
 *
 * @author gessle
 */
public class SaturnV extends Rocket{
    
    public SaturnV() {
        super("Saturn V", 130000, 3);
    }
    
    public void doTvInteview() {
        System.out.println("TV inteview starting...");
        
        for(Astronaut a: astronauts) {
            System.out.println(a.getName() + " says hello!");
        }
        
    }
    
}
