/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.gpiste.starbase;

/**
 *
 * @author gessle
 */
public class Starship extends Rocket{
    
    public Starship() {
        super("Starship", 150000, 100);
    }
    
    public void land() {
        System.out.println(name + " has landed successfully!");
    }
    
}
