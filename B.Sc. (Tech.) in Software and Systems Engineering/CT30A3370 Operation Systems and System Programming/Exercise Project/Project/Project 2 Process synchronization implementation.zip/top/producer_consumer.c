#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define BUFFER_SIZE 10
#define NUM_PRODUCERS 5
#define NUM_CONSUMERS 5
#define NUM_ITEMS 20

// define semaphores

sem_t empty, full, mutex;
int buffer[BUFFER_SIZE];
int count = 0;

// define producer and consumer functions

void *producer(void *arg)
{
    int id = *(int *)arg;
    int item;

    for (int i = 0; i < NUM_ITEMS; i++)
    {
        item = rand() % 100;  // generate a random item
        sem_wait(&empty);     // decrement empty semaphore
        sem_wait(&mutex);     // enter critical section
        buffer[count] = item; // add item to buffer
        count++;
        printf("Producer %d produced item %d\n", id, item);
        sem_post(&mutex); // leave critical section
        sem_post(&full);  // increment full semaphore
    }

    pthread_exit(NULL);
}

void *consumer(void *arg)
{
    int id = *(int *)arg;
    int item;

    for (int i = 0; i < NUM_ITEMS; i++)
    {
        sem_wait(&full);          // decrement full semaphore
        sem_wait(&mutex);         // enter critical section
        item = buffer[count - 1]; // take item from buffer
        count--;
        printf("Consumer %d consumed item %d\n", id, item);
        sem_post(&mutex); // leave critical section
        sem_post(&empty); // increment empty semaphore
    }

    pthread_exit(NULL);
}

// main function

int main()
{
    pthread_t producers[NUM_PRODUCERS], consumers[NUM_CONSUMERS];
    int producer_ids[NUM_PRODUCERS], consumer_ids[NUM_CONSUMERS];

    // initialize semaphores
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);
    sem_init(&mutex, 0, 1);

    // create producers
    for (int i = 0; i < NUM_PRODUCERS; i++)
    {
        producer_ids[i] = i;
        pthread_create(&producers[i], NULL, producer, &producer_ids[i]);
    }

    // create consumers
    for (int i = 0; i < NUM_CONSUMERS; i++)
    {
        consumer_ids[i] = i;
        pthread_create(&consumers[i], NULL, consumer, &consumer_ids[i]);
    }

    // join producers
    for (int i = 0; i < NUM_PRODUCERS; i++)
    {
        pthread_join(producers[i], NULL);
    }

    // join consumers
    for (int i = 0; i < NUM_CONSUMERS; i++)
    {
        pthread_join(consumers[i], NULL);
    }

    // destroy semaphores
    {
        sem_destroy(&empty);
        sem_destroy(&full);
        sem_destroy(&mutex);
    }
}
