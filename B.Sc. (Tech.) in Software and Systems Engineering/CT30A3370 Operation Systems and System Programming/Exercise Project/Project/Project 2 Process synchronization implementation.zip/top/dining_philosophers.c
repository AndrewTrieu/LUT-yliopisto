#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>

#define NUM_PHILOSOPHERS 5

sem_t forks[NUM_PHILOSOPHERS];
sem_t mutex;
volatile sig_atomic_t stop = 0;

void *philosopher(void *arg)
{
    int id = *((int *)arg);
    int left_fork = id;
    int right_fork = (id + 1) % NUM_PHILOSOPHERS;

    while (!stop)
    {
        // Think
        printf("Philosopher %d is thinking\n", id);

        // Pick up forks
        sem_wait(&mutex);
        sem_wait(&forks[left_fork]);
        sem_wait(&forks[right_fork]);
        sem_post(&mutex);

        // Eat
        printf("Philosopher %d is eating\n", id);

        // Put down forks
        sem_post(&forks[left_fork]);
        sem_post(&forks[right_fork]);
    }

    return NULL;
}

void signal_handler(int signum)
{
    if (signum == SIGINT)
    {
        stop = 1;
    }
}

int main()
{
    pthread_t threads[NUM_PHILOSOPHERS];
    int ids[NUM_PHILOSOPHERS];

    // Initialize semaphores
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        sem_init(&forks[i], 0, 1);
    }
    sem_init(&mutex, 0, 1);

    // Register signal handler
    signal(SIGINT, signal_handler);

    // Create philosopher threads
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        ids[i] = i;
        pthread_create(&threads[i], NULL, philosopher, (void *)&ids[i]);
    }

    // Wait for signal
    while (!stop)
    {
        sleep(1);
    }

    // Stop philosopher threads
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        pthread_cancel(threads[i]);
        pthread_join(threads[i], NULL);
    }

    // Destroy semaphores
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        sem_destroy(&forks[i]);
    }
    sem_destroy(&mutex);

    return 0;
}
