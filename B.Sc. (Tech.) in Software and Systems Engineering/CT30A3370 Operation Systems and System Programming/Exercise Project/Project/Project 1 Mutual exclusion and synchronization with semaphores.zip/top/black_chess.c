#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <fcntl.h>
#include <sys/stat.h>

int main()
{
    sem_t *hong, *hei;
    int steps = 0;

    // initialize semaphores
    hong = sem_open("hong", O_CREAT, 0666, 0);
    hei = sem_open("hei", O_CREAT, 0666, 1);

    while (steps < 10)
    {
        // wait for red side to move
        sem_wait(hong);
        printf("Black moves.\n");
        steps++;

        // signal that black side has moved
        sem_post(hei);
    }

    // close semaphores
    sem_close(hong);
    sem_close(hei);

    return 0;
}
