#include <stdio.h>
#include <stdlib.h>

#define MEM_SIZE 640 // total memory size
#define MAX_PARTS 32 // maximum number of partitions

// partition structure
typedef struct
{
    int start;         // starting address
    int end;           // ending address
    int size;          // size of partition
    struct part *next; // pointer to next partition in chain
} part;

part *free_list = NULL; // pointer to free partition chain

// initialize free partition chain with a single partition that spans the entire memory
void init_memory()
{
    part *new_part = (part *)malloc(sizeof(part));
    new_part->start = 0;
    new_part->end = MEM_SIZE - 1;
    new_part->size = MEM_SIZE;
    new_part->next = NULL;
    free_list = new_part;
}

// allocate a partition of the given size using the first-fit algorithm
part *alloc_first_fit(int size)
{
    part *prev_part = NULL;
    part *curr_part = free_list;
    while (curr_part != NULL)
    {
        if (curr_part->size >= size)
        {
            // found a free partition that is big enough
            int new_start = curr_part->start;
            int new_end = new_start + size - 1;
            curr_part->start = new_end + 1;
            curr_part->size -= size;
            part *new_part = (part *)malloc(sizeof(part));
            new_part->start = new_start;
            new_part->end = new_end;
            new_part->size = size;
            new_part->next = NULL;
            if (prev_part == NULL)
            {
                // allocate from the beginning of the free partition chain
                free_list = curr_part->size > 0 ? curr_part : curr_part->next;
            }
            else
            {
                // allocate from the middle or end of the free partition chain
                prev_part->next = curr_part->size > 0 ? curr_part : curr_part->next;
            }
            return new_part;
        }
        else
        {
            prev_part = curr_part;
            curr_part = curr_part->next;
        }
    }
    return NULL; // no free partition found
}

// allocate a partition of the given size using the best-fit algorithm
part *alloc_best_fit(int size)
{
    part *prev_part = NULL;
    part *curr_part = free_list;
    part *best_part = NULL;
    while (curr_part != NULL)
    {
        if (curr_part->size >= size && (best_part == NULL || curr_part->size < best_part->size))
        {
            // found a free partition that is big enough and better than the current best fit
            best_part = curr_part;
        }
        prev_part = curr_part;
        curr_part = curr_part->next;
    }
    if (best_part != NULL)
    {
        // allocate from the best-fit partition
        int new_start = best_part->start;
        int new_end = new_start + size - 1;
        best_part->start = new_end + 1;
        best_part->size -= size;
        part *new_part = (part *)malloc(sizeof(part));
        new_part->start = new_start;
        new_part->end = new_end;
        new_part->size = size;
        new_part->next = NULL;
        if (prev_part == NULL)
            // allocate from the beginning of the free partition chain
            free_list = best_part->size > 0 ? best_part : best_part->next;
        return new_part;
    }
    else
    {
        return NULL; // no free partition found
    }
}

// recycle a partition and add it to the free partition chain in ascending order of starting address
void free_partition(part *p)
{
    part *prev_part = NULL;
    part *curr_part = free_list;
    while (curr_part != NULL && curr_part->start < p->start)
    {
        prev_part = curr_part;
        curr_part = curr_part->next;
    }
    if (prev_part == NULL)
    {
        // add at the beginning of the free partition chain
        p->next = curr_part;
        free_list = p;
    }
    else
    {
        // add in the middle or end of the free partition chain
        prev_part->next = p;
        p->next = curr_part;
    }
    // merge adjacent free partitions
    while (curr_part != NULL && curr_part->start == p->end + 1)
    {
        p->end = curr_part->end;
        p->size += curr_part->size;
        p->next = curr_part->next;
        free(curr_part);
        curr_part = p->next;
    }
    while (prev_part != NULL && prev_part->end == p->start - 1)
    {
        prev_part->end = p->end;
        prev_part->size += p->size;
        prev_part->next = p->next;
        free(p);
        p = prev_part;
        prev_part = prev_part->next;
    }
}

// display the current status of the free partition chain
void display_free_partitions()
{
    printf("Free partitions:\n");
    part *curr_part = free_list;
    while (curr_part != NULL)
    {
        printf("[%d, %d] (%d bytes)\n", curr_part->start, curr_part->end, curr_part->size);
        curr_part = curr_part->next;
    }
    printf("\n");
}

// test the dynamic partition allocation and recycling process
int main()
{
    init_memory();
    printf("Initial free partition - First-fit:\n");
    display_free_partitions();

    // First Fit
    part *job1a = alloc_first_fit(130);
    printf("Allocated partition for job1:\n");
    display_free_partitions();
    part *job2a = alloc_first_fit(60);
    printf("Allocated partition for job2:\n");
    display_free_partitions();
    part *job3a = alloc_first_fit(100);
    printf("Allocated partition for job3:\n");
    display_free_partitions();
    free_partition(job2a);
    printf("Recycled partition for job2:\n");
    display_free_partitions();
    part *job4a = alloc_first_fit(200);
    printf("Allocated partition for job4:\n");
    display_free_partitions();
    free_partition(job3a);
    printf("Recycled partition for job3:\n");
    display_free_partitions();
    free_partition(job1a);
    printf("Recycled partition for job1:\n");
    display_free_partitions();
    part *job5a = alloc_first_fit(140);
    printf("Allocated partition for job5:\n");
    display_free_partitions();
    part *job6a = alloc_first_fit(60);
    printf("Allocated partition for job6:\n");
    display_free_partitions();
    part *job7a = alloc_first_fit(50);
    printf("Allocated partition for job7:\n");
    display_free_partitions();
    free_partition(job6a);
    printf("Recycled partition for job6:\n");
    display_free_partitions();

    init_memory();
    printf("Initial free partition - Best-fit:\n");
    display_free_partitions();

    // Best Fit
    part *job1b = alloc_best_fit(130);
    printf("Allocated partition for job1:\n");
    display_free_partitions();
    part *job2b = alloc_best_fit(60);
    printf("Allocated partition for job2:\n");
    display_free_partitions();
    part *job3b = alloc_best_fit(100);
    printf("Allocated partition for job3:\n");
    display_free_partitions();
    free_partition(job2b);
    printf("Recycled partition for job2:\n");
    display_free_partitions();
    part *job4b = alloc_best_fit(200);
    printf("Allocated partition for job4:\n");
    display_free_partitions();
    free_partition(job3b);
    printf("Recycled partition for job3:\n");
    display_free_partitions();
    free_partition(job1b);
    printf("Recycled partition for job1:\n");
    display_free_partitions();
    part *job5b = alloc_best_fit(140);
    printf("Allocated partition for job5:\n");
    display_free_partitions();
    part *job6b = alloc_best_fit(60);
    printf("Allocated partition for job6:\n");
    display_free_partitions();
    part *job7b = alloc_best_fit(50);
    printf("Allocated partition for job7:\n");
    display_free_partitions();
    free_partition(job6b);
    printf("Recycled partition for job6:\n");
    display_free_partitions();

    return 0;
}