/*
example include file
*/

void hello(char name[]);